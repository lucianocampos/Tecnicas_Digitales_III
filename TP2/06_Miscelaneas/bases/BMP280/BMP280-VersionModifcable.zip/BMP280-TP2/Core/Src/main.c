/* USER CODE BEGIN Header */
/**
  **************************
  * @file           : main.c
  * @brief          : Main program body
  **************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  **************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "bmp280_spi.h"
#include <stdio.h>
#include <string.h>
/* USER CODE END Includes */
#define BMP_CS_GPIO_Port GPIOA
#define BMP_CS_Pin GPIO_PIN_4
char txBuf[100];
bmp280_t bmp;


/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
SPI_HandleTypeDef hspi1;


UART_HandleTypeDef huart1;

/* Sea level pressure for altitude calculation */
float sea_level_hPa = 1013.25f;

/* Menu API */
void menu_print(void);
char menu_get_choice(void);
void menu_handle(char choice);

/* BMP280 setters with readback verification */
void bmp280_set_oversampling_temp(bmp280_t *dev, uint8_t osrs_t);
void bmp280_set_oversampling_pres(bmp280_t *dev, uint8_t osrs_p);
void bmp280_set_mode        (bmp280_t *dev, uint8_t mode);
void bmp280_set_filter      (bmp280_t *dev, uint8_t filter);
void bmp280_set_standby     (bmp280_t *dev, uint8_t t_sb);


/* Sea level pressure for altitude calculation */



/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_SPI1_Init(void);
static void MX_USART1_UART_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
void menu_print(void)
{
    const char *m =
        "\r\nSeleccione opcion:\r\n"
        "1) Oversampling Temp\r\n"
        "2) Oversampling Pres\r\n"
        "3) Filtro IIR\r\n"
        "4) Tiempo Standby\r\n"
        "5) Modo Operacion\r\n"
        "6) Sea Level (hPa)\r\n"
        "7) Ver mediciones\r\n"     // <-- nueva línea
        "q) Salir menu\r\n"
        "Elección: ";
    HAL_UART_Transmit(&huart1, (uint8_t*)m, strlen(m), HAL_MAX_DELAY);
}

/* Read one character from UART (blocking) */
char menu_get_choice(void)
{
    char c;
    HAL_UART_Receive(&huart1, (uint8_t*)&c, 1, HAL_MAX_DELAY);
    /* Echo and newline */
    HAL_UART_Transmit(&huart1, (uint8_t*)&c, 1, HAL_MAX_DELAY);
    HAL_UART_Transmit(&huart1, (uint8_t*)"\r\n", 2, HAL_MAX_DELAY);
    return c;
}

/* Handle the user's menu choice */
void menu_handle(char choice)
{
    char buf[100];
    uint8_t v;
    char s[5] = {0};

    switch (choice)
    {
        case '1':  // Temp oversampling
            HAL_UART_Transmit(&huart1,
                (uint8_t*)"Temp OSRS: 0=skip,1=x1,2=x2,4=x4,8=x8,16=x16\r\nValor: ",
                80, HAL_MAX_DELAY);
            HAL_UART_Receive(&huart1, &s[0], 2, HAL_MAX_DELAY);
            v = (uint8_t)atoi(s);
            bmp280_set_oversampling_temp(&bmp, v);
            snprintf(buf, sizeof(buf), "Temp OSRS set = %u\r\n", v);
            HAL_UART_Transmit(&huart1, (uint8_t*)buf, strlen(buf), HAL_MAX_DELAY);
            break;

        case '2':  // Pressure oversampling
            HAL_UART_Transmit(&huart1,
                (uint8_t*)"Pres OSRS: 0=skip,1=x1,2=x2,4=x4,8=x8,16=x16\r\nValor: ",
                80, HAL_MAX_DELAY);
            HAL_UART_Receive(&huart1, &s[0], 2, HAL_MAX_DELAY);
            v = (uint8_t)atoi(s);
            bmp280_set_oversampling_pres(&bmp, v);
            snprintf(buf, sizeof(buf), "Pres OSRS set = %u\r\n", v);
            HAL_UART_Transmit(&huart1, (uint8_t*)buf, strlen(buf), HAL_MAX_DELAY);
            break;

        case '3':  // IIR filter
            HAL_UART_Transmit(&huart1,
                (uint8_t*)"Filtro IIR: 0=off,1=2,2=4,3=8,4=16\r\nValor: ",
                60, HAL_MAX_DELAY);
            HAL_UART_Receive(&huart1, &s[0], 1, HAL_MAX_DELAY);
            v = (uint8_t)(s[0] - '0');
            bmp280_set_filter(&bmp, v);
            snprintf(buf, sizeof(buf), "Filtro set = %u\r\n", v);
            HAL_UART_Transmit(&huart1, (uint8_t*)buf, strlen(buf), HAL_MAX_DELAY);
            break;

        case '4':  // Standby time
            HAL_UART_Transmit(&huart1,
                (uint8_t*)
                "Standby (ms):\r\n"
                "0=0.5,1=62.5,2=125,3=250,4=500,5=1000,6=2000,7=4000\r\nValor: ",
                100, HAL_MAX_DELAY);
            HAL_UART_Receive(&huart1, &s[0], 1, HAL_MAX_DELAY);
            v = (uint8_t)(s[0] - '0');
            bmp280_set_standby(&bmp, v);
            snprintf(buf, sizeof(buf), "Standby idx = %u\r\n", v);
            HAL_UART_Transmit(&huart1, (uint8_t*)buf, strlen(buf), HAL_MAX_DELAY);
            break;

        case '5':  // Mode
            HAL_UART_Transmit(&huart1,
                (uint8_t*)"Modo: 0=sleep,1=forced,3=normal\r\nValor: ",
                50, HAL_MAX_DELAY);
            HAL_UART_Receive(&huart1, &s[0], 1, HAL_MAX_DELAY);
            v = (uint8_t)(s[0] - '0');
            bmp280_set_mode(&bmp, v);
            snprintf(buf, sizeof(buf), "Modo set = %u\r\n", v);
            HAL_UART_Transmit(&huart1, (uint8_t*)buf, strlen(buf), HAL_MAX_DELAY);
            break;

        case '6':  // Sea level
            HAL_UART_Transmit(&huart1,
                (uint8_t*)"Presión nivel mar (hPa) [800-1200]: ",
                40, HAL_MAX_DELAY);
            HAL_UART_Receive(&huart1, (uint8_t*)s, 4, HAL_MAX_DELAY);
            sea_level_hPa = atof(s);
            snprintf(buf, sizeof(buf),
                     "Sea level = %.2f hPa\r\n", sea_level_hPa);
            HAL_UART_Transmit(&huart1, (uint8_t*)buf, strlen(buf), HAL_MAX_DELAY);
            break;

        case '7':  // Ver mediciones
        {
            uint8_t ctrl, cfg;
            char out[256];

            // Lecturas
            float t = bmp280_read_temp(&bmp);
            float p = bmp280_read_pres(&bmp) / 100.0f;
            float a = bmp280_read_alt(&bmp, sea_level_hPa);

            // Extraer osrs y modo del CTRL_MEAS
            bmp280_read(&bmp, BMP280_REG_CTRL_MEAS, &ctrl, 1);
            uint8_t osrs_t = (ctrl >> 5) & 0x07;
            uint8_t osrs_p = (ctrl >> 2) & 0x07;
            uint8_t mode   =  ctrl        & 0x03;

            // Extraer filtro y standby del CONFIG
            bmp280_read(&bmp, BMP280_REG_CONFIG, &cfg, 1);
            uint8_t filter  = (cfg >> 2) & 0x07;
            uint8_t standby =  cfg        & 0x07;

            // Formatear salida
            int len = snprintf(out, sizeof(out),
                "\r\n--- Mediciones y Configuracion ---\r\n"
                "Temp       = %.2f C\r\n"
                "Presion    = %.2f hPa\r\n"
                "Altitud    = %.2f m\r\n"
                "Modo       = %u (%s)\r\n"
                "OSRS Temp  = %u\r\n"
                "OSRS Pres  = %u\r\n"
                "Filtro IIR = %u\r\n"
                "Standby    = %u\r\n"
                "------------------------------------\r\n",
                t, p, a,
                mode, (mode==0?"sleep":mode==1?"forced":"normal"),
                osrs_t, osrs_p,
                filter,
                standby
            );

            HAL_UART_Transmit(&huart1, (uint8_t*)out, len, HAL_MAX_DELAY);
            break;
        }

        case 'q':
        case 'Q':
            HAL_UART_Transmit(&huart1,
                (uint8_t*)"\r\nSaliendo menú...\r\n", 18, HAL_MAX_DELAY);
            break;

        default:
            HAL_UART_Transmit(&huart1,
                (uint8_t*)"\r\nOpción inválida\r\n", 18, HAL_MAX_DELAY);
            break;
    }
}

/* === Setter implementations with readback === */

void bmp280_set_oversampling_temp(bmp280_t *dev, uint8_t osrs_t)
{
    uint8_t ctrl;
    char msg[64];
    bmp280_read(dev, BMP280_REG_CTRL_MEAS, &ctrl, 1);
    ctrl = (ctrl & ~(0x07 << 5)) | ((osrs_t & 0x07) << 5);
    bmp280_write8(dev, BMP280_REG_CTRL_MEAS, ctrl);

    /* Read back and report */
    bmp280_read(dev, BMP280_REG_CTRL_MEAS, &ctrl, 1);
    uint8_t back = (ctrl >> 5) & 0x07;
    snprintf(msg, sizeof(msg),
             "CTRL_MEAS(0xF4)=0x%02X  OSRS_T back=%u\r\n",
             ctrl, back);
    HAL_UART_Transmit(&huart1, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
}

void bmp280_set_oversampling_pres(bmp280_t *dev, uint8_t osrs_p)
{
    uint8_t ctrl;
    char msg[64];
    bmp280_read(dev, BMP280_REG_CTRL_MEAS, &ctrl, 1);
    ctrl = (ctrl & ~(0x07 << 2)) | ((osrs_p & 0x07) << 2);
    bmp280_write8(dev, BMP280_REG_CTRL_MEAS, ctrl);

    bmp280_read(dev, BMP280_REG_CTRL_MEAS, &ctrl, 1);
    uint8_t back = (ctrl >> 2) & 0x07;
    snprintf(msg, sizeof(msg),
             "CTRL_MEAS(0xF4)=0x%02X  OSRS_P back=%u\r\n",
             ctrl, back);
    HAL_UART_Transmit(&huart1, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
}

void bmp280_set_mode(bmp280_t *dev, uint8_t mode)
{
    uint8_t ctrl;
    char msg[64];
    bmp280_read(dev, BMP280_REG_CTRL_MEAS, &ctrl, 1);
    ctrl = (ctrl & ~0x03) | (mode & 0x03);
    bmp280_write8(dev, BMP280_REG_CTRL_MEAS, ctrl);

    bmp280_read(dev, BMP280_REG_CTRL_MEAS, &ctrl, 1);
    uint8_t back = ctrl & 0x03;
    snprintf(msg, sizeof(msg),
             "CTRL_MEAS(0xF4)=0x%02X  MODE back=%u\r\n",
             ctrl, back);
    HAL_UART_Transmit(&huart1, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
}

void bmp280_set_filter(bmp280_t *dev, uint8_t filter)
{
    uint8_t cfg;
    char msg[64];
    bmp280_read(dev, BMP280_REG_CONFIG, &cfg, 1);
    cfg = (cfg & ~(0x07 << 2)) | ((filter & 0x07) << 2);
    bmp280_write8(dev, BMP280_REG_CONFIG, cfg);

    bmp280_read(dev, BMP280_REG_CONFIG, &cfg, 1);
    uint8_t back = (cfg >> 2) & 0x07;
    snprintf(msg, sizeof(msg),
             "CONFIG(0xF5)=0x%02X  FILTER back=%u\r\n",
             cfg, back);
    HAL_UART_Transmit(&huart1, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
}

void bmp280_set_standby(bmp280_t *dev, uint8_t t_sb)
{
    uint8_t cfg;
    char msg[64];
    bmp280_read(dev, BMP280_REG_CONFIG, &cfg, 1);
    cfg = (cfg & ~0x07) | (t_sb & 0x07);
    bmp280_write8(dev, BMP280_REG_CONFIG, cfg);

    bmp280_read(dev, BMP280_REG_CONFIG, &cfg, 1);
    uint8_t back = cfg & 0x07;
    snprintf(msg, sizeof(msg),
             "CONFIG(0xF5)=0x%02X  STANDBY back=%u\r\n",
             cfg, back);
    HAL_UART_Transmit(&huart1, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
}



int main(void)
{
    /* Inicializa HAL, reloj y periféricos básicos --------------------------*/
    HAL_Init();
    SystemClock_Config();
    MX_GPIO_Init();
    MX_SPI1_Init();
    MX_USART1_UART_Init();

    /* Espera breve para estabilidad del sensor */
    HAL_Delay(100);

    /* ---------- Configura el descriptor BMP280 y realiza init ------------ */
    bmp.hspi    = &hspi1;           /* puntero al manejador SPI1 */
    bmp.cs_port = BMP_CS_GPIO_Port; /* macros generados por CubeMX */
    bmp.cs_pin  = BMP_CS_Pin;

    if (bmp280_init(&bmp) != HAL_OK) {
        const char *err = "ERROR: BMP280 no responde!\r\n";
        HAL_UART_Transmit(&huart1, (uint8_t*)err, strlen(err), HAL_MAX_DELAY);
        Error_Handler();
    }

    /* Mensaje de arranque por UART */
    const char *init_msg = "Sistema iniciado correctamente!\r\n";
    HAL_UART_Transmit(&huart1, (uint8_t*)init_msg, strlen(init_msg), HAL_MAX_DELAY);

    HAL_UART_Transmit(&huart1,(uint8_t*)"\r\n--- BMP280 CONFIG MENU ---\r\n", 28, HAL_MAX_DELAY);

    /* ----------------------- Bucle principal ----------------------------- */
    while (1)
    {
    	menu_print();
    	        char c = menu_get_choice();
    	        menu_handle(c);
    }
}



  /* USER CODE END 3 */


/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief SPI1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI1_Init(void)
{

  /* USER CODE BEGIN SPI1_Init 0 */

  /* USER CODE END SPI1_Init 0 */

  /* USER CODE BEGIN SPI1_Init 1 */

  /* USER CODE END SPI1_Init 1 */
  /* SPI1 parameter configuration*/
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_2LINES;
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_16;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI1_Init 2 */

  /* USER CODE END SPI1_Init 2 */

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET);

  /*Configure GPIO pin : PA4 */
  GPIO_InitStruct.Pin = GPIO_PIN_4;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
