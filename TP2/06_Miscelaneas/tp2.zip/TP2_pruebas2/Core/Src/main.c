/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

#include "bmp280_spi.h"
#include <stdio.h>
#include <string.h>

ADC_HandleTypeDef hadc1;

SPI_HandleTypeDef hspi1;

TIM_HandleTypeDef htim1;

UART_HandleTypeDef huart1;
UART_HandleTypeDef huart2;

#define BMP_CS_GPIO_Port GPIOA
#define BMP_CS_Pin GPIO_PIN_4
char txBuf[100];
bmp280_t bmp;

#define STX               0x02
#define ETX               0x03
#define SLAVE_ADDR        0x01   // la dirección que le asignaste a tu Blue Pill
#define CMD_BMP_READ_MEAS 0x13   // código CMP para “leer medidas BMP280”

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_ADC1_Init(void);
static void MX_SPI1_Init(void);
static void MX_TIM1_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_USART2_UART_Init(void);



/// Envía un buffer de 'len' bytes- DE-RE
HAL_StatusTypeDef RS485_Send(const uint8_t *buf, uint16_t len) {
  // 1) Habilita transmisión
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_12, GPIO_PIN_SET);
  HAL_Delay(1);  // ~1 ms para darle tiempo al hardware a pasar a modo “driver enabled”

  // 2) Envía por UART
  HAL_StatusTypeDef st = HAL_UART_Transmit(&huart1, (uint8_t*)buf, len, HAL_MAX_DELAY);

  // 3) Espera a que los últimos bits salgan por la línea y vuelve a modo “recibir”
  HAL_Delay(1);
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_12, GPIO_PIN_RESET);

  return st;
}

HAL_StatusTypeDef RS485_Receive(uint8_t *buf, uint16_t len, uint32_t timeout) {
  // Asegúrate de que DE/RE está en LOW
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_12, GPIO_PIN_RESET);
  return HAL_UART_Receive(&huart1, buf, len, timeout);
}


#define CMD_BMP_WRITE_REG 0x10
#define CMD_BMP_READ_REG  0x11
#define CMD_BMP_RESET     0x12
#define CMD_BMP_READ_MEAS 0x13

/* Prototypes ---------------------------------------------------------------*/
static uint16_t crc16(const uint8_t *data, uint16_t len);
static void     sendResponse(uint8_t cmd, uint8_t *data, uint8_t len);
static void     sendAck(uint8_t cmd);
static void     sendNak(uint8_t cmd);

/* Globals ------------------------------------------------------------------*/
UART_HandleTypeDef huart1;
bmp280_t          bmp;
uint8_t           rxBuf[32];

/*------------------------------------------------------------------------------*/
/*  CRC-16 Modbus (poly 0xA001, init 0xFFFF)                                    */
/*------------------------------------------------------------------------------*/
static uint16_t crc16(const uint8_t *data, uint16_t len) {
  uint16_t crc = 0xFFFF;
  for (uint16_t i = 0; i < len; i++) {
    crc ^= data[i];
    for (uint8_t b = 0; b < 8; b++)
      crc = (crc & 1) ? (crc >> 1) ^ 0xA001 : (crc >> 1);
  }
  return crc;
}

/*------------------------------------------------------------------------------*/
/*  Construye y envía por UART1 una respuesta CMP                               */
/*------------------------------------------------------------------------------*/
static void sendResponse(uint8_t cmd, uint8_t *data, uint8_t len) {
  uint8_t hdr[4] = { STX, SLAVE_ADDR, cmd, len };
  HAL_UART_Transmit(&huart1, hdr, 4, HAL_MAX_DELAY);
  if (len) HAL_UART_Transmit(&huart1, data, len, HAL_MAX_DELAY);

  // CRC sobre [ADDR, CMD, LEN, payload...]
  uint8_t crcBuf[3 + len];
  crcBuf[0] = SLAVE_ADDR;
  crcBuf[1] = cmd;
  crcBuf[2] = len;
  if (len) memcpy(crcBuf + 3, data, len);

  uint16_t c = crc16(crcBuf, 3 + len);
  uint8_t crcBytes[2] = { (uint8_t)(c & 0xFF), (uint8_t)(c >> 8) };
  HAL_UART_Transmit(&huart1, crcBytes, 2, HAL_MAX_DELAY);

  uint8_t etx = ETX;
  HAL_UART_Transmit(&huart1, &etx, 1, HAL_MAX_DELAY);
}

static void sendAck(uint8_t cmd) { sendResponse(cmd, NULL, 0); }
static void sendNak(uint8_t cmd) { uint8_t e = 1; sendResponse(cmd, &e, 1); }


int main(void)
{

  HAL_Init();

  SystemClock_Config();

  MX_GPIO_Init();
  MX_ADC1_Init();
  MX_SPI1_Init();
  MX_TIM1_Init();
  MX_USART1_UART_Init();
  MX_USART2_UART_Init();


  /* Espera breve para estabilidad del sensor */
     HAL_Delay(100);

     /* ---------- Configura el descriptor BMP280 y realiza init ------------ */
     bmp.hspi    = &hspi1;           /* puntero al manejador SPI1 */
     bmp.cs_port = BMP_CS_GPIO_Port; /* macros generados por CubeMX */
     bmp.cs_pin  = BMP_CS_Pin;

     if (bmp280_init(&bmp) != HAL_OK) {
         const char *err = "ERROR: BMP280 no responde!\r\n";
         HAL_UART_Transmit(&huart1, (uint8_t*)err, strlen(err), HAL_MAX_DELAY);
         Error_Handler();
     }

     /* Mensaje de arranque por UART */
     const char *init_msg = "Sistema iniciado correctamente!\r\n";
     HAL_UART_Transmit(&huart1, (uint8_t*)init_msg, strlen(init_msg), HAL_MAX_DELAY);


  while (1)
  {
//primeras pruebas importantes- backup sobre el uso del bmp280 en el github:
//https://github.com/abelwu2001/5to-Anio/blob/main/Tecnicas-Digitales-III/Tp_2/Pruebas_con_bmp280%2BRs285/bmp280_spi.c

	  // Enciende LED (LOW)
	    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET);
	    HAL_Delay(500);
	    // Apaga LED (HIGH)
	    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_SET);
	    HAL_Delay(500);

	    // 1) Espera STX
	    HAL_UART_Transmit(&huart1, (uint8_t*)"DBG: esperando STX...\r\n", 22, HAL_MAX_DELAY);
	    uint8_t b;
	    HAL_UART_Receive(&huart1, &b, 1, HAL_MAX_DELAY);
	    char dbg1[30];
	    snprintf(dbg1, sizeof(dbg1), "DBG: recibido byte=0x%02X\r\n", b);
	    HAL_UART_Transmit(&huart1, (uint8_t*)dbg1, strlen(dbg1), HAL_MAX_DELAY);
	    if (b != STX) continue;

	    // 2) Cabecera: ADDR, CMD, LEN
	    HAL_UART_Transmit(&huart1, (uint8_t*)"DBG: leyendo cabecera...\r\n", 25, HAL_MAX_DELAY);
	    uint8_t addr, cmd, len;
	    HAL_UART_Receive(&huart1, &addr, 1, HAL_MAX_DELAY);
	    HAL_UART_Receive(&huart1, &cmd,  1, HAL_MAX_DELAY);
	    HAL_UART_Receive(&huart1, &len,  1, HAL_MAX_DELAY);
	    char dbg2[50];
	    snprintf(dbg2, sizeof(dbg2),
	             "DBG: addr=0x%02X cmd=0x%02X len=%d\r\n",
	             addr, cmd, len);
	    HAL_UART_Transmit(&huart1, (uint8_t*)dbg2, strlen(dbg2), HAL_MAX_DELAY);
	    if (addr != SLAVE_ADDR) {
	      HAL_UART_Transmit(&huart1, (uint8_t*)"DBG: addr no coincide, descarto\r\n",
	                        33, HAL_MAX_DELAY);
	      HAL_UART_Receive(&huart1, rxBuf, len + 3, HAL_MAX_DELAY);
	      continue;
	    }

	    // 3) Payload (si hay)
	    if (len) {
	      HAL_UART_Transmit(&huart1, (uint8_t*)"DBG: leyendo payload...\r\n", 26, HAL_MAX_DELAY);
	      HAL_UART_Receive(&huart1, rxBuf, len, HAL_MAX_DELAY);
	    }

	    // 4) CRC_L, CRC_H, ETX
	    HAL_UART_Transmit(&huart1, (uint8_t*)"DBG: leyendo CRC y ETX...\r\n", 27, HAL_MAX_DELAY);
	    uint8_t crcL, crcH, etx;
	    HAL_UART_Receive(&huart1, &crcL, 1, HAL_MAX_DELAY);
	    HAL_UART_Receive(&huart1, &crcH, 1, HAL_MAX_DELAY);
	    HAL_UART_Receive(&huart1, &etx,  1, HAL_MAX_DELAY);
	    snprintf(dbg1, sizeof(dbg1),
	             "DBG: crcL=0x%02X crcH=0x%02X ETX=0x%02X\r\n",
	             crcL, crcH, etx);
	    HAL_UART_Transmit(&huart1, (uint8_t*)dbg1, strlen(dbg1), HAL_MAX_DELAY);
	    if (etx != ETX) {
	      HAL_UART_Transmit(&huart1, (uint8_t*)"DBG: ETX incorrecto\r\n", 21, HAL_MAX_DELAY);
	      continue;
	    }

	    // 5) Verificar CRC
	    HAL_UART_Transmit(&huart1, (uint8_t*)"DBG: verificando CRC...\r\n", 24, HAL_MAX_DELAY);
	    uint8_t chk[3 + len];
	    chk[0] = addr; chk[1] = cmd; chk[2] = len;
	    if (len) memcpy(chk+3, rxBuf, len);
	    uint16_t rec = (uint16_t)crcL | ((uint16_t)crcH << 8);
	    uint16_t calc = crc16(chk, 3 + len);
	    snprintf(dbg2, sizeof(dbg2),
	             "DBG: CRC calc=0x%04X rec=0x%04X\r\n",
	             calc, rec);
	    HAL_UART_Transmit(&huart1, (uint8_t*)dbg2, strlen(dbg2), HAL_MAX_DELAY);
	    if (calc != rec) {
	      HAL_UART_Transmit(&huart1, (uint8_t*)"DBG: CRC fallo\r\n", 16, HAL_MAX_DELAY);
	      continue;
	    }

	    // 6) Dispatch sólo BMP280
	    HAL_UART_Transmit(&huart1, (uint8_t*)"DBG: entrando a switch(cmd)\r\n", 29, HAL_MAX_DELAY);
	    switch(cmd) {
	      case CMD_BMP_WRITE_REG:
	        HAL_UART_Transmit(&huart1, (uint8_t*)"DBG: CMD_WRITE_REG\r\n", 20, HAL_MAX_DELAY);
	        if (len==2 && bmp280_write8(&bmp, rxBuf[0], rxBuf[1])==HAL_OK) {
	          sendAck(cmd);
	          HAL_UART_Transmit(&huart1, (uint8_t*)"DBG: ACK enviado\r\n", 18, HAL_MAX_DELAY);
	        } else {
	          sendNak(cmd);
	          HAL_UART_Transmit(&huart1, (uint8_t*)"DBG: NAK enviado\r\n", 18, HAL_MAX_DELAY);
	        }
	        break;

	      case CMD_BMP_READ_REG:
	        HAL_UART_Transmit(&huart1, (uint8_t*)"DBG: CMD_READ_REG\r\n", 20, HAL_MAX_DELAY);
	        if (len==1) {
	          uint8_t v;
	          if (bmp280_read(&bmp, rxBuf[0], &v, 1)==HAL_OK) {
	            sendResponse(cmd, &v, 1);
	            HAL_UART_Transmit(&huart1, (uint8_t*)"DBG: RESP_REG enviado\r\n", 23, HAL_MAX_DELAY);
	          } else {
	            sendNak(cmd);
	            HAL_UART_Transmit(&huart1, (uint8_t*)"DBG: NAK enviado\r\n", 18, HAL_MAX_DELAY);
	          }
	        } else {
	          sendNak(cmd);
	          HAL_UART_Transmit(&huart1, (uint8_t*)"DBG: LEN invalido\r\n", 19, HAL_MAX_DELAY);
	        }
	        break;

	      case CMD_BMP_RESET:
	        HAL_UART_Transmit(&huart1, (uint8_t*)"DBG: CMD_RESET\r\n", 17, HAL_MAX_DELAY);
	        if (bmp280_write8(&bmp, BMP280_REG_RESET, BMP280_RESET_VALUE)==HAL_OK) {
	          sendAck(cmd);
	          HAL_UART_Transmit(&huart1, (uint8_t*)"DBG: ACK reset\r\n", 16, HAL_MAX_DELAY);
	        } else {
	          sendNak(cmd);
	          HAL_UART_Transmit(&huart1, (uint8_t*)"DBG: NAK reset\r\n", 16, HAL_MAX_DELAY);
	        }
	        break;

	      case CMD_BMP_READ_MEAS:
	        HAL_UART_Transmit(&huart1, (uint8_t*)"DBG: CMD_READ_MEAS\r\n", 21, HAL_MAX_DELAY);
	        {
	          float T = bmp280_read_temp(&bmp);
	          float P = bmp280_read_pres(&bmp) / 100.0f;
	          float A = bmp280_read_alt(&bmp, 1013.25f);
	          uint8_t out[12];
	          memcpy(out+0, &T, 4);
	          memcpy(out+4, &P, 4);
	          memcpy(out+8, &A, 4);
	          sendResponse(cmd, out, 12);
	          HAL_UART_Transmit(&huart1, (uint8_t*)"DBG: RESP_MEAS enviado\r\n", 24, HAL_MAX_DELAY);
	        }
	        break;

	      default:
	        sendNak(cmd);
	        HAL_UART_Transmit(&huart1, (uint8_t*)"DBG: CMD invalido\r\n", 19, HAL_MAX_DELAY);
	        break;
	      }

  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_ADC;
  PeriphClkInit.AdcClockSelection = RCC_ADCPCLK2_DIV6;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */

  /** Common config
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ScanConvMode = ADC_SCAN_ENABLE;
  hadc1.Init.ContinuousConvMode = ENABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 3;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_0;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SamplingTime = ADC_SAMPLETIME_7CYCLES_5;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_1;
  sConfig.Rank = ADC_REGULAR_RANK_2;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_8;
  sConfig.Rank = ADC_REGULAR_RANK_3;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

/**
  * @brief SPI1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI1_Init(void)
{

  /* USER CODE BEGIN SPI1_Init 0 */

  /* USER CODE END SPI1_Init 0 */

  /* USER CODE BEGIN SPI1_Init 1 */

  /* USER CODE END SPI1_Init 1 */
  /* SPI1 parameter configuration*/
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_2LINES;
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_16;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI1_Init 2 */

  /* USER CODE END SPI1_Init 2 */

}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};
  TIM_BreakDeadTimeConfigTypeDef sBreakDeadTimeConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 71;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 4095;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  if (HAL_TIM_PWM_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCNPolarity = TIM_OCNPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  sConfigOC.OCIdleState = TIM_OCIDLESTATE_RESET;
  sConfigOC.OCNIdleState = TIM_OCNIDLESTATE_RESET;
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM2;
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_4) != HAL_OK)
  {
    Error_Handler();
  }
  sBreakDeadTimeConfig.OffStateRunMode = TIM_OSSR_DISABLE;
  sBreakDeadTimeConfig.OffStateIDLEMode = TIM_OSSI_DISABLE;
  sBreakDeadTimeConfig.LockLevel = TIM_LOCKLEVEL_OFF;
  sBreakDeadTimeConfig.DeadTime = 0;
  sBreakDeadTimeConfig.BreakState = TIM_BREAK_DISABLE;
  sBreakDeadTimeConfig.BreakPolarity = TIM_BREAKPOLARITY_HIGH;
  sBreakDeadTimeConfig.AutomaticOutput = TIM_AUTOMATICOUTPUT_DISABLE;
  if (HAL_TIMEx_ConfigBreakDeadTime(&htim1, &sBreakDeadTimeConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */
  HAL_TIM_MspPostInit(&htim1);

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4|GPIO_PIN_12, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14, GPIO_PIN_RESET);

  /*Configure GPIO pins : PA4 PA12 */
  GPIO_InitStruct.Pin = GPIO_PIN_4|GPIO_PIN_12;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PB1 PB10 PB11 */
  GPIO_InitStruct.Pin = GPIO_PIN_1|GPIO_PIN_10|GPIO_PIN_11;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : PB12 PB13 PB14 */
  GPIO_InitStruct.Pin = GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET);
  /*Configure GPIO pin : PC13 */
   GPIO_InitStruct.Pin   = GPIO_PIN_13;
   GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_PP;
   GPIO_InitStruct.Pull  = GPIO_NOPULL;
   GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
   HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
