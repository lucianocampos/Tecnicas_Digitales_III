/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f1xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim);

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define DEBUG_LED_Pin GPIO_PIN_13
#define DEBUG_LED_GPIO_Port GPIOC
#define DIN_01_Pin GPIO_PIN_3
#define DIN_01_GPIO_Port GPIOA
#define DIN_02_Pin GPIO_PIN_4
#define DIN_02_GPIO_Port GPIOA
#define DIN_03_Pin GPIO_PIN_5
#define DIN_03_GPIO_Port GPIOA
#define PWM_01_Pin GPIO_PIN_6
#define PWM_01_GPIO_Port GPIOA
#define PWM_02_Pin GPIO_PIN_7
#define PWM_02_GPIO_Port GPIOA
#define UART_RS485_DE_Pin GPIO_PIN_1
#define UART_RS485_DE_GPIO_Port GPIOB
#define UART_RS485_TX_Pin GPIO_PIN_10
#define UART_RS485_TX_GPIO_Port GPIOB
#define UART_RS485_RX_Pin GPIO_PIN_11
#define UART_RS485_RX_GPIO_Port GPIOB
#define SPI_NSS_Pin GPIO_PIN_12
#define SPI_NSS_GPIO_Port GPIOB
#define SPI_SCK_Pin GPIO_PIN_13
#define SPI_SCK_GPIO_Port GPIOB
#define SPI_MISO_Pin GPIO_PIN_14
#define SPI_MISO_GPIO_Port GPIOB
#define SPI_MOSI_Pin GPIO_PIN_15
#define SPI_MOSI_GPIO_Port GPIOB
#define UART_TTL_TX_Pin GPIO_PIN_9
#define UART_TTL_TX_GPIO_Port GPIOA
#define UART_TTL_RX_Pin GPIO_PIN_10
#define UART_TTL_RX_GPIO_Port GPIOA
#define DOUT_01_Pin GPIO_PIN_3
#define DOUT_01_GPIO_Port GPIOB
#define DOUT_02_Pin GPIO_PIN_4
#define DOUT_02_GPIO_Port GPIOB
#define DOUT_03_Pin GPIO_PIN_6
#define DOUT_03_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
